import 'package:flutter_test/flutter_test.dart';
import 'package:biodata_diri/main.dart';

void main() {
  testWidgets('Biodata mahasiswa tampil dengan benar', (WidgetTester tester) async {
    // Build aplikasi BiodataApp
    await tester.pumpWidget(const BiodataApp());

    // Tunggu hingga semua widget selesai dirender
    await tester.pumpAndSettle();

    // Cek apakah data penting mahasiswa tampil di layar
    expect(find.text('Elma Ardelia'), findsOneWidget);
    expect(find.text('NIM: 241080200039'), findsOneWidget);
    expect(find.text('Program studi: Informatika'), findsOneWidget);
    expect(find.text('Biodata Diri'), findsWidgets);
  });
}